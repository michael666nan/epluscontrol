from .constant_setpoint import ConstantSetpoint
from .model_predictive_control import ModelPredictiveControl
from .night_setback import NightSetback
from .random_setpoint import RandomSetpoint
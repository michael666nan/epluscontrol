# EnergyPlus Control

A Python library for implementing control systems with EnergyPlus models.

## Installation

```bash
pip install epluscontrol